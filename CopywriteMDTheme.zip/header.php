<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="Michael Cleland">
<title>Copywrite M.D. | Copy, Marketing, and Design</title>
<link rel="shortcut icon" href="https://imgur.com/wlN5xPE.png" />
<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">

<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous" id="bootstrapcdn">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

<script src="https://use.fontawesome.com/3ae7bdceda.js"></script>




<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-114300075-1"></script>;
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());

gtag('config', 'UA-114300075-1');
</script>

<script id="mcjs">!function(c,h,i,m,p){m=c.createElement(h),p=c.getElementsByTagName(h)[0],m.async=1,m.src=i,p.parentNode.insertBefore(m,p)}(document,"script","https://chimpstatic.com/mcjs-connected/js/users/0c48dc7c04693ac82c21f28ff/fae6ab014cdee3e5fe5ce9e05.js");</script>
<script>$(function () {
  $(document).scroll(function () {
    var $nav = $(".navbar-toggleable-md");
    $nav.toggleClass('scrolled', $(this).scrollTop() > $nav.height());
  });
});</script>

<script>$(function () {
  $(document).scroll(function () {
    var $span = $(".contactinfo");
    $span.toggleClass('scrolled', $(this).scrollTop() > 100);
  });
});</script>

<script>$(function () {
  $(document).scroll(function () {
    var $span = $(".navbar-toggler");
    $span.toggleClass('custom-toggler', $(this).scrollTop() > 100);
  });
});</script>

<?php wp_head(); ?>
</head>