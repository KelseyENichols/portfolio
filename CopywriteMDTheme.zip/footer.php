<!--Footer-->
<footer class="footer">
<div class="container">

<span class="text-muted">
	<div class="row">
	<div class="col-xs-12 col-sm-6">
<p><span><a href="mailto:michaelcleland@copywritemd.com">michaelcleland@copywritemd.com</a> </span></p>
</div>
<div class="col-xs-12 col-sm-6">

 <p> <a href="http://www.instagram.com/copywrite_md/" target="_blank"><i class="fa fa-instagram fa-2x pull-right" aria-hidden="true"></i></a><a href="https://www.linkedin.com/company/cg-marketing-web-design/" target="_blank"><i class="fa fa-linkedin-square fa-2x pull-right"></i></a><a 
 	></i></a>
<a href="https://www.facebook.com/CG-Marketing-Design-1766714453636183/" target="_blank"><i class="fa fa-facebook-square fa-2x pull-right" aria-hidden="true"></i></a>
 
 </p>
</div>
&copy; Michael Cleland 2018 <br>
&amp; Cristian Ghiurea</span>
</div>
</footer>