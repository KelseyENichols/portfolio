<?php get_header(); ?>

<body>

<!--Navigation-->
<nav class="navbar navbar-toggleable-md fixed-top navbar-light bg-light">
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="http://www.copywritemd.com.com/"><img src="https://imgur.com/wlN5xPE.png" height="85px"></a>
  <span class="navbar-text">
    
  </span>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mx-auto mt-2 mt-lg-0">
       <?php wp_nav_menu( array( 'theme_location' => 'primary-menu' ) ); ?>

	  </ul>
	 <!--search bar-->
<span class="contactinfo">
<a href="mailto:michaelcleland@copywritemd.com">michaelcleland@copywritemd.com</a> - <a href="tel+1-562-208-6643">(562) 208-6643</a>
</span>
  </div>
</nav>
<!--Branding-->
<!--<div class="jumbotron jumbotron-fluid" id="jumbotron-main">-->
<!--<div class="container">-->
 <!--Carousel start-->
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
 <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
 <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
 <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>

  </ol>
  <div class="carousel-inner" role="listbox">

    <div class="carousel-item active">
      <img class="img-fluid" src="https://imgur.com/rXAzM3w.jpg" alt="First slide">

    </div>
    <div class="carousel-item">
      <img class="img-fluid" src="https://imgur.com/F80ENFA.jpg" alt="Second slide">

    </div>
    
<div class="carousel-item">
      <img class="img-fluid" src="https://imgur.com/l2VZK5O.jpg" alt="Second slide">

    </div>
<div class="carousel-item">
      <img class="img-fluid" src="https://imgur.com/ySWFyvI.jpg" alt="Second slide">

    </div>
<div class="carousel-item">
      <img class="img-fluid" src="https://imgur.com/UtRaJIb.jpg" alt="Second slide">

    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<!--Carousel end-->
  </div>
</div>
<!--</div>-->
<!--Page Body-->

<div class="row no-gutters">
<div class="col-xs-12 col-sm-6" id="typewriter">
<script src="//my.visme.co/visme.js"></script><div class="visme_d" id="typeGraphic" data-url="mxnz0z88-interactive-graphics" data-w="800" data-h="400" data-domain="my"></div>


</div>
<div class="col-xs-12 col-sm-6">
<div class="body-main">
<div class="text-center"><img class="img-fluid" src="https://imgur.com/6sXZKB8.jpg" height="375px" width="325px"></div>

</div>
</div>
</div>
<hr>
<!--Buttons-->
<div class="servicesback">
<div class="text-center">
<h3>Your Prescription</h3>
</div>

<div class="container">
<div class="row">
<div class="col-xs-12">


<?php
// TO SHOW THE PAGE CONTENTS
    while ( have_posts() ) : the_post(); ?> <!--Because the_content() works only inside a WP Loop -->
        <div class="entry-content-page">
            <?php the_content(); ?> <!-- Page Content -->
        </div><!-- .entry-content-page -->

    <?php
endwhile; //resetting the page loop
wp_reset_query(); //resetting the page query
?>

</div>

</div>
</div>
</div>

<!--CTA-->
<div class="jumbotron jumbotron-fluid" id="cta">
  <div class="container">
   <div class="text-center">
    <h3 class="display-5">Get your free marketing audit.</h3>
	<p><a class="contactbtn" href="http://www.cgmarketinginc.com/contact/"><button class="btn btn-success btn-sm">Contact Us</button></a></p>
  </div>
  </div>
</div>



<?php get_footer(); ?>
</body>