<?php get_header(); ?>


<!--Navigation-->
<nav class="navbar navbar-toggleable-md fixed-top navbar-light bg-light">
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="http://www.copywritemd.com/"><img src="https://imgur.com/wlN5xPE.png" height="85px"></a>
  <span class="navbar-text">
    
  </span>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mx-auto mt-2 mt-lg-0">
       <?php wp_nav_menu( array( 'theme_location' => 'primary-menu' ) ); ?>
	  </ul>
	 <!--search bar-->
<span class="contactinfo">
<a href="mailto:michaelcleland@copywritemd.com">michaelcleland@copywritemd.com</a> - <a href="tel+1-562-208-6643">(562) 208-6643</a>
</span>
  </div>
</nav>
<!--Branding-->
<div class="jumbotron jumbotron-fluid" id="subpage">
  <div class="container">
  <div class="text-center">
    <h3>BLOG</h3>

	</div>
  </div>
</div>
<!--Page Body-->
<!--Blog Content-->
<div class="container">
<div class="row">
<div class="col-xs-12 col-sm-8">
<?php if ( have_posts() ) : ?>
<?php while ( have_posts() ) : the_post(); ?>
  <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="post-header">
       <div class="date"><?php the_time( 'M j y' ); ?></div>
       <h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
       <div class="author"><?php the_author(); ?></div>
    </div><!--end post header-->
    <div class="entry clear">
       <?php if ( function_exists( 'add_theme_support' ) ) the_post_thumbnail(); ?>
       <?php the_content(); ?>
       <?php edit_post_link(); ?>
       <?php wp_link_pages(); ?> </div>
    <!--end entry-->
    <div class="post-footer">
       <div class="comments"><?php comments_popup_link( 'Leave a Comment', '1 Comment', '% Comments' ); ?></div>
    </div><!--end post footer-->
    </div><!--end post-->
<?php endwhile; /* rewind or continue if all posts have been fetched */ ?>
    <div class="navigation index">
       <div class="alignleft"><?php next_posts_link( 'Older Entries' ); ?></div>
       <div class="alignright"><?php previous_posts_link( 'Newer Entries' ); ?></div>
    </div><!--end navigation-->
<?php else : ?>
<?php endif; ?>
</div>


<?php get_sidebar(); ?>
</div>
</div>
<!--CTA-->
<div class="jumbotron jumbotron-fluid" id="cta">
  <div class="container">
   <div class="text-center">
    <h3 class="display-5">Get your free marketing audit.</h3>
	<p><a href=" http://www.cgmarketinginc.com/contact/"><button class="btn btn-success btn-sm">Contact Us</button></a></p>
  </div>
  </div>
</div>


<?php get_footer(); ?>
